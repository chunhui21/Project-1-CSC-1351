import java.text.NumberFormat;
import java.util.Arrays;

public class aOrderedList {
    /**
     * Contains the methods for adding and deleting cars and sorting them.
     * Also sets up the structure of the output
     *
     * CSC 1351 Programming Project No 1
     * Section 002
     *
     * @author Chun Hui Situ
     * @since October 23, 2023
     *
     */
    private final int SIZEINCREMENTS = 20;
    private Car[] oList;
    private int listSize;
    private int numObjects;
    private int curr;
    public aOrderedList() {
        numObjects = 0;
        listSize = SIZEINCREMENTS;
        oList = new Car[listSize];
    }

    public void add(Car newCar) {
        /**
         * Method to add new car and sorting it and increase the size of the list if needed
         *
         * CSC 1351 Programming Project No 1
         * Section 002
         *
         * @author Chun Hui Situ
         * @since October 23, 2023
         *
         */
        if (numObjects >= listSize) {
            listSize += SIZEINCREMENTS;
            Car[] newList = new Car[listSize];
            System.arraycopy(oList, 0, newList, 0, numObjects);
            oList = newList;
        }


        oList[numObjects] = newCar;
        numObjects++;
        Arrays.sort(oList, 0, numObjects);
    }

    public void deleteCar(Car deleteCar) {
        /**
         * Method to delete car by comparing the make and year of the car while also sorting list
         *
         * CSC 1351 Programming Project No 1
         * Section 002
         *
         * @author Chun Hui Situ
         * @since October 23, 2023
         *
         */
        int indexToDelete = -1;

        for (int i = 0; i < numObjects; i++) {
            if (oList[i].getMake().equals(deleteCar.getMake()) && oList[i].getYear() == (deleteCar.getYear())) {
                indexToDelete = i;
                break;
            }

        }

        if (indexToDelete != -1) {
            for (int i = indexToDelete; i < numObjects - 1; i++) {
                oList[i] = oList[i + 1];
            }
            numObjects--;

            if (listSize > SIZEINCREMENTS && numObjects < listSize - SIZEINCREMENTS) {
                listSize -= SIZEINCREMENTS;
                Car[] newList = new Car[listSize];
                System.arraycopy(oList, 0, newList, 0, numObjects);
                oList = newList;
            }
        }
    }

    public String toString() {
        /**
         * Uses StringBuilder() to set up the structure of the output
         *
         * CSC 1351 Programming Project No 1
         * Section 002
         *
         * @author Chun Hui Situ
         * @since October 23, 2023
         *
         */
        NumberFormat formatter = NumberFormat.getCurrencyInstance();
        formatter.setMaximumFractionDigits(0);

        StringBuilder sb = new StringBuilder();
        sb.append("Number of cars: \t" + numObjects + "\n\n");
        for (int i = 0; i < numObjects; i++) {
            Car a = oList[i];
            sb.append("Make: \t" + a.getMake() + "\n");
            sb.append("Year: \t" + a.getYear() + "\n");
            sb.append("Price: \t" + formatter.format(a.getPrice()) + "\n\n");
        }
        return sb.toString();
    }

    public int size() {
        return numObjects;
    }
    public Car get(int index) {
        return oList[index];
    }

    public boolean isEmpty() {
        return numObjects == 0;
    }

    public void remove(int indexToDelete) {
        for (int i = indexToDelete; i < numObjects - 1; i++) {
            oList[i] = oList[i + 1];
        }
        numObjects--;
    }
}