public class Car implements Comparable<Car>{
    /**
     * Class allows Car to be compared
     *
     * CSC 1351 Programming Project No 1
     * Section 002
     *
     * @author Chun Hui Situ
     * @since October 23, 2023
     *
     */
    private String make;
    private int year;
    private int price;

    public Car(String Make, int Year, int Price) {
        make = Make;
        year = Year;
        price = Price;
    }

    public String getMake() {
        return make;
    }
    public int getYear() {
        return year;
    }
    public int getPrice() {
        return price;
    }

    public int compareTo(Car other) {
        /**
         * method that allows the elements to be compared
         *
         * CSC 1351 Programming Project No 1
         * Section 002
         *
         * @author Chun Hui Situ
         * @since October 23, 2023
         *
         */
        int makeComparison = this.make.compareTo(other.make);
        if (makeComparison != 0) {
            return makeComparison;
        }
        if (this.year != other.year) {
            return Integer.compare(this.year, other.year);
        }

        return Integer.compare(this.price, other.price);
    }

    @Override
    public String toString() {
        return "Make: " + make + ", Year : " + year + ", Price: " + price + ";";
    }
}