/**
 * Program takes an input file and creates and output file that adds all the cars that are in the list from the input file
 * after some moderations
 *
 * CSC 1351 Programming Project No 1
 * Section 002
 *
 * @author Chun Hui Situ
 * @since October 23, 2023
 *
 */

import java.io.PrintWriter;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;


public class Prog01_aOrderedList {
    /**
     * Runs the main program
     *
     * CSC 1351 Programming Project No 1
     * Section 002
     *
     * @author Chun Hui Situ
     * @since October 23, 2023
     *
     */

    static Scanner in = new Scanner(System.in);
    public static void main(String[] args) {
        /**
         * Asks user for the input file, adds/delete cars from input file into outputfile
         *
         * CSC 1351 Programming Project No 1
         * Section 002
         *
         * @author Chun Hui Situ
         * @since October 23, 2023
         *
         */

        aOrderedList carList = new aOrderedList();
        try {
            Scanner inputFile = GetInputFile("Enter input filename: ");
            while (inputFile.hasNextLine()) {
                String line = inputFile.nextLine();
                String[] parts = line.split(",");

                if (parts[0].equals("A")) {
                    String make = parts[1];
                    int year = Integer.parseInt(parts[2]);
                    int price = Integer.parseInt(parts[3]);

                    Car newCar = new Car(make, year, price);
                    carList.add(newCar);
                }

                else {
                    String make = parts[1];
                    int year = Integer.parseInt(parts[2]);
                    int price = 0;
                    Car deleteCar = new Car(make, year, price);
                    carList.deleteCar((deleteCar));
                }
            }
            inputFile.close();
        } catch (FileNotFoundException e) {
            System.out.println("The file was not found.");
            e.printStackTrace();
        }


        try {
            PrintWriter out = GetOutputFile("Enter output filename: ");
            out.write(carList.toString());
            out.close();
            in.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        in.close();
    }

    public static Scanner GetInputFile(String UserPrompt) throws FileNotFoundException {
        /**
         * Scans for input File user mentioned. If user enters a file that can't be found, asks if
         * user wants to continue searching for a file. If user inputs "N" , throws a FileNotFoundException
         *
         * CSC 1351 Programming Project No 1
         * Section 002
         *
         * @author Chun Hui Situ
         * @since October 23, 2023
         *
         */
        Scanner userInput = in;
        Scanner inputFileScanner = null;
        String inputFileName;
        while (true) {
            System.out.print(UserPrompt);
            inputFileName = userInput.nextLine();
            File inputFile = new File(inputFileName);
            if (inputFile.exists()) {
                inputFileScanner = new Scanner(inputFile);
                break;
            } else {
                System.out.println("File specified <" + inputFileName + "> does not exist. Would you like to continue? <Y/N> ");
                String continueChoice = userInput.nextLine();
                if (continueChoice.equalsIgnoreCase("N")) {
                    throw new FileNotFoundException("User cancelled the operation.");
                }
            }
        }
        return inputFileScanner;
    }

    public static PrintWriter GetOutputFile(String UserPrompt) throws FileNotFoundException{
        /**
         * Prints the output file
         *
         * CSC 1351 Programming Project No 1
         * Section 002
         *
         * @author Chun Hui Situ
         * @since October 23, 2023
         *
         */
        System.out.print(UserPrompt);
        String filename = in.nextLine();
        System.out.print(filename);
        try {
            PrintWriter out = new PrintWriter(filename);
            return out;
        } catch (FileNotFoundException e) {
            System.out.print("Something went wrong");
            return GetOutputFile("Invalid filename entered. Please reenter.");
        }
    }
}







